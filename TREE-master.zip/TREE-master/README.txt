TREE. LAB 4.
Student: Samrega A.A. IU8 - 21.